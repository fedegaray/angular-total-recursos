export interface Usuario {
    id: string;
    avatar: string;
    nombre: string;
  }