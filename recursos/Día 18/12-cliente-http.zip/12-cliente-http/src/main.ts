import { bootstrapApplication } from '@angular/platform-browser';

import { ComponenteApp } from './app/app.component';

bootstrapApplication(ComponenteApp).catch((err) => console.error(err));
