import { Component } from '@angular/core';

@Component({
  selector: 'app-raiz',
  standalone: true,
  templateUrl: './app.component.html'
})
export class AppComponent {

}
