import { Component } from '@angular/core';

@Component({
  selector: 'app-rectangulo',
  standalone: true,
  imports: [],
  templateUrl: './rectangulo.component.html',
  styleUrl: './rectangulo.component.css',
})
export class RectanguloComponent {
  // Pendiente: Implementar vinculación bidireccional personalizada

  alResetear() {
    // ...
  }
}
