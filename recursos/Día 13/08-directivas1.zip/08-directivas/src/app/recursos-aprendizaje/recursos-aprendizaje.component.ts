import { Component } from '@angular/core';

@Component({
  selector: 'app-recursos-aprendizaje',
  templateUrl: './recursos-aprendizaje.component.html',
  styleUrl: './recursos-aprendizaje.component.css',
  standalone: true,
})
export class RecursosAprendizajeComponent {}
