export type Permiso = 'admin' | 'usuario' | 'invitado';
