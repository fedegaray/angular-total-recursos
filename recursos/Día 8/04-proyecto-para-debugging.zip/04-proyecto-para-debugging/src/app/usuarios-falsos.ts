export const USUARIOS_FALSOS = [
    {
      id: 'u1',
      nombre: 'Antonia Céspedes',
      avatar: 'usuario-1.png',
    },
    {
      id: 'u2',
      nombre: 'Emilia Torres',
      avatar: 'usuario-2.png',
    },
    {
      id: 'u3',
      nombre: 'Marcos Jeremías',
      avatar: 'usuario-3.png',
    },
    {
      id: 'u4',
      nombre: 'David Mercado',
      avatar: 'usuario-4.png',
    },
    {
      id: 'u5',
      nombre: 'Pamela Chan',
      avatar: 'usuario-5.png',
    },
    {
      id: 'u6',
      nombre: 'Adrián Serbio',
      avatar: 'usuario-6.png',
    },
  ];