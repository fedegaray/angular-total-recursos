import { Component } from '@angular/core';

import { CicloDeVidaComponent } from "./lifecycle/lifecycle.component";

@Component({
    selector: 'app-raiz',
    standalone: true,
    templateUrl: './app.component.html',
    imports: [CicloDeVidaComponent]
})
export class AppComponent {
  componenteCicloDeVidaEsVisible = false;
  textoCicliDeVida = 'Un número aleatorio: ' + Math.random() * 100;

  alAlternarVisibilidadCicloDeVida() {
    this.componenteCicloDeVidaEsVisible = !this.componenteCicloDeVidaEsVisible;
  }

  alCambiarTextoCicliDeVida() {
    this.textoCicliDeVida = 'Un número aleatorio: ' + Math.random() * 100;
  }
}
