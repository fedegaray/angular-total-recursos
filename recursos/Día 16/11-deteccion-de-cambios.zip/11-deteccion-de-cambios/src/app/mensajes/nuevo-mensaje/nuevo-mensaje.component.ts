import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nuevo-mensaje',
  standalone: true,
  templateUrl: './nuevo-mensaje.component.html',
  styleUrl: './nuevo-mensaje.component.css',
  imports: [FormsModule],
})
export class NuevoMensajeComponent {
  @Output() agregar = new EventEmitter<string>();
  mensaje = '';

  get salidaDepuracion() {
    console.log('[NuevoMensaje] Enlace "salidaDepuracion" re-evaluado.');
    return 'Salida de Depuración del Componente NuevoMensaje';
  }

  onSubmit() {
    if (this.mensaje.trim()) {
      this.agregar.emit(this.mensaje);
      this.mensaje = '';
    }
  }
}
